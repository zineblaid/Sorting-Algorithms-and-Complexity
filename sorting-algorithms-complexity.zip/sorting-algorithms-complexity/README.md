# Sorting Algorithms and Complexity Analysis

A small educational C project implementing common sorting algorithms and examining their performance.

## Algorithms included

- Selection Sort
- Bubble Sort
- Insertion Sort
- Quick Sort
- Merge Sort
- Comb Sort

Each program reads an integer array, sorts it in ascending order, displays the sorted result, and reports operation counters where implemented.

## Repository structure

```text
sorting-algorithms-complexity/
├── README.md
├── src/
│   ├── selection_sort.c
│   ├── bubble_sort.c
│   ├── insertion_sort.c
│   ├── quick_sort.c
│   ├── merge_sort.c
│   └── comb_sort.c
└── benchmarks/
    └── README.md
```

## Complexity overview

| Algorithm | Best time | Average time | Worst time | Auxiliary space |
|---|---:|---:|---:|---:|
| Selection Sort | O(n²) | O(n²) | O(n²) | O(1) |
| Bubble Sort* | O(n) | O(n²) | O(n²) | O(1) |
| Insertion Sort | O(n) | O(n²) | O(n²) | O(1) |
| Quick Sort | O(n log n) | O(n log n) | O(n²) | O(log n) average recursion |
| Merge Sort | O(n log n) | O(n log n) | O(n log n) | O(n) |
| Comb Sort | commonly near O(n²) | depends on input | O(n²) | O(1) |

\* The Bubble Sort implementation in this repository includes an early-exit optimization, so its best case is O(n) when the input is already sorted.

Complexity describes how resource usage grows as the input size `n` increases. Actual execution time depends on the compiler, hardware, input data, and implementation details.

## Build and run

You need a C compiler such as GCC or Clang.

Example using GCC:

```bash
gcc -std=c99 -Wall -Wextra -pedantic src/selection_sort.c -o selection_sort
./selection_sort
```

Replace `selection_sort.c` and `selection_sort` with the algorithm file and executable name you want to run.

Example for Merge Sort:

```bash
gcc -std=c99 -Wall -Wextra -pedantic src/merge_sort.c -o merge_sort
./merge_sort
```

## Input example

```text
Enter the number of elements: 5
Enter 5 integers: 8 3 5 1 4
```

The program prints the sorted array and operation counts.

## Notes about operation counters

- **Comparisons** counts element-to-element comparisons performed by the algorithm.
- **Moves / swaps** is implementation-dependent. Some algorithms swap elements, while others copy or shift elements. Therefore, counters from different algorithms are not always directly equivalent.
- The Quick Sort pivot strategy in this educational implementation uses the last element as the pivot. Already sorted or reverse-sorted inputs can therefore trigger its O(n²) worst case.
- The programs are intended for learning and experimentation, not as production sorting libraries.

## Learning goals

- Understand how sorting algorithms work.
- Compare time and space complexity.
- Observe comparisons and data movements.
- Practice implementing algorithms in C.
